# ************************************************************
# Sequel Ace SQL dump
# Version 3041
#
# https://sequel-ace.com/
# https://github.com/Sequel-Ace/Sequel-Ace
#
# Host: localhost (MySQL 5.7.28)
# Database: acensor-tech
# Generation Time: 2022-11-29 22:24:59 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE='NO_AUTO_VALUE_ON_ZERO', SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table categories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;

INSERT INTO `categories` (`id`, `name`, `status`, `created_at`, `updated_at`)
VALUES
	(1,'PHP',1,'2022-11-29 16:52:43','2022-11-29 16:52:45'),
	(2,'Laravel',1,'2022-11-29 16:52:33','2022-11-29 16:52:33'),
	(3,'Vue.js',1,'2022-11-29 16:52:33','2022-11-29 16:52:33'),
	(4,'React',0,'2022-11-29 16:52:33','2022-11-29 16:52:33'),
	(5,'Typescript',1,'2022-11-29 16:52:33','2022-11-29 16:52:33'),
	(6,'Javascript',1,'2022-11-29 16:52:33','2022-11-29 16:52:33'),
	(7,'Python',0,'2022-11-29 16:52:33','2022-11-29 16:52:33'),
	(8,'c++',1,'2022-11-29 22:09:46','2022-11-29 22:09:46');

/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table failed_jobs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `failed_jobs`;

CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table migrations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;

INSERT INTO `migrations` (`id`, `migration`, `batch`)
VALUES
	(2,'2014_10_12_100000_create_password_resets_table',1),
	(3,'2019_08_19_000000_create_failed_jobs_table',1),
	(4,'2019_12_14_000001_create_personal_access_tokens_table',1),
	(7,'2022_11_29_163818_create_posts_table',2),
	(8,'2022_11_29_163828_create_categories_table',2),
	(9,'2022_11_29_163851_add_category_id_fk_to_posts',2),
	(10,'2022_11_29_164346_add_category_id_fk_to_posts_table',3),
	(11,'2014_10_12_000000_create_users_table',4);

/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table password_resets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table personal_access_tokens
# ------------------------------------------------------------

DROP TABLE IF EXISTS `personal_access_tokens`;

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table posts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `posts`;

CREATE TABLE `posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `publish_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `posts_category_id_foreign` (`category_id`),
  CONSTRAINT `posts_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;

INSERT INTO `posts` (`id`, `title`, `content`, `status`, `category_id`, `publish_date`, `created_at`, `updated_at`)
VALUES
	(2,'Queen ordering off her knowledge, as there was.','<p>Ea consequatur enim et voluptatem magni inventore similique. Possimus sed sint enim deleniti et ipsam. Autem dolor voluptatem delectus. Eaque veritatis iusto neque numquam voluptas aut.</p><p>Aliquid perspiciatis molestias qui eius id. Molestias occaecati voluptas consequatur qui deserunt nam repellendus. Molestiae vel ipsam est facilis. Eveniet id aut sed minima quisquam iusto.</p><p>Est sit perspiciatis deserunt et harum est laborum. Aut quaerat nam quaerat fugiat facilis. Laudantium qui aut sit molestiae officia. Et et qui consectetur amet molestias.</p><p>Eveniet repellat iste eos temporibus harum quasi voluptas. Sed aut omnis voluptas ducimus et aut. Omnis saepe dolores dolorem illum ducimus. Repellat placeat itaque consequuntur sit ea ullam est.</p><p>A iure sunt deserunt est. Voluptatem voluptate aut consequatur ut. Et esse quidem ratione rerum eaque eum. Ut deserunt nihil perferendis voluptatibus consequuntur ea voluptas.</p><p>Fugiat molestias et dolorem nobis velit iste. Ut autem quis officiis et labore tempora a. Quaerat ab quaerat enim veritatis est nostrum. Numquam soluta sint hic amet omnis dolore et.</p><p>Magnam tenetur assumenda incidunt inventore consequatur. Odio reiciendis omnis impedit est et ratione. Earum iste excepturi est quasi et aut. Culpa ab libero ut maiores qui.</p>',1,1,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(3,'THE VOICE OF THE SLUGGARD,\"\' said the King added.','<p>Aut aut omnis magnam magnam accusantium dolores quia porro. Voluptas ut optio beatae corrupti tempora. Eius non ratione voluptatem doloribus beatae nostrum facere. Cum dolor nostrum et est.</p><p>Molestiae ut ducimus natus eaque eum. Nihil est fuga officia id deleniti ea ipsa vel. Ullam molestiae enim nihil tenetur corporis ut. Est sed nulla libero maiores soluta quae.</p>',0,1,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(4,'And the Eaglet bent down its head down, and felt.','<p>Id id quam beatae soluta rerum. Harum dicta totam soluta laudantium aliquam tenetur. Et quas eius ut vero eaque molestias assumenda. Nihil magni alias repellat porro aut. Ullam architecto sint quisquam alias eligendi voluptas.</p><p>Quae nihil voluptas voluptatem. Molestias voluptatem omnis omnis aut quia totam. Provident aut amet earum autem dolorem sed numquam.</p><p>Ipsum odio nulla cumque consequatur eius rerum dolores. Deserunt temporibus nam et adipisci laudantium quam.</p>',0,2,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(5,'Alice, as she fell very slowly, for she was.','<p>Dolores quia quis ut non. Omnis sit voluptas nihil provident iste est. Necessitatibus minus rerum inventore non. Facere sunt ab ea id incidunt illo quo.</p><p>Voluptatem dolores consequuntur dolores asperiores cum et necessitatibus. Dicta sunt qui minima nisi. Sunt eum voluptas in in rerum corporis illo.</p><p>Animi alias aliquid voluptas saepe nam quod placeat nulla. Fugiat vel saepe omnis neque. Delectus amet in omnis suscipit corporis sint aut. Ut quia sint dignissimos corporis sed expedita.</p><p>Delectus aut officia sed. Sed voluptatem dolorem animi. Commodi repellat ea excepturi quasi aliquid. Non est saepe voluptatem est nobis omnis.</p>',1,2,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(6,'I? Ah, THAT\'S the great wonder is, that I\'m.','<p>Nostrum illum rerum enim non sed. Nulla quia voluptatum rerum sunt. Aspernatur velit nulla dolor odio.</p><p>Sed magni dolorem enim itaque. Aliquid ad ut rem dolores. Magnam soluta laudantium dicta sit et minus omnis. Maxime omnis animi eum nulla dolores ut quisquam. Corporis consequatur delectus dolores quo placeat fugit qui adipisci.</p><p>Ea voluptatibus dolor voluptatem aliquid explicabo dolor quia. Nisi aspernatur at fuga. Vitae perferendis veritatis molestiae voluptatem consequatur et nihil. Consectetur quo aliquid totam deserunt aliquid vero omnis dolor.</p><p>Iste modi esse quo perspiciatis quos. Nisi placeat quia neque sed voluptatem deleniti aspernatur. Ea qui nemo fugiat possimus non et illo. Temporibus veritatis maiores sunt dicta laborum architecto.</p><p>Aliquam labore et fugiat atque dolorem fugit. Soluta dignissimos quia sit accusamus aut ut. Deserunt autem qui et magnam id. Aliquam libero saepe aspernatur ut occaecati.</p><p>Quod atque qui odit. Dolores accusamus vel consequuntur magnam. Quia ipsa dolorem aut nobis.</p><p>Sequi ad praesentium impedit et in reiciendis. Iusto cupiditate dolor id possimus.</p><p>Sunt laborum natus asperiores expedita similique. Sed sunt in omnis sit voluptatum voluptas cumque. Modi quidem tempore ea neque. Debitis est necessitatibus praesentium fugiat eum. Rerum est eaque magnam odio ex.</p>',0,6,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(7,'Here the other side of WHAT? The other side will.','<p>In pariatur placeat sed. Ullam quaerat vel qui. Voluptas facere exercitationem fugit quod ut porro voluptatem.</p><p>Harum assumenda facere veniam autem suscipit est. Harum amet ratione quaerat. Velit atque consequuntur in qui aut. Eum ut iure et quisquam reprehenderit quis qui.</p>',0,6,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(8,'Mock Turtle yawned and shut his eyes.--\'Tell her.','<p>Pariatur qui vero recusandae ut consequatur cupiditate sunt. Necessitatibus fugit totam consequatur commodi dolorem sint. Et nam et facilis. Itaque ex labore excepturi dolorem. Nulla labore reiciendis repellat officiis dolorum sunt ipsum.</p><p>Et rem dolor non repudiandae expedita hic sed. Modi recusandae non incidunt et optio sed voluptatem. Et architecto aspernatur ut neque assumenda nobis sed.</p><p>Distinctio sapiente sed illum. Commodi omnis dolorem velit corrupti vel.</p><p>Quo perspiciatis ab at delectus impedit quos. Voluptates aperiam cum facilis sunt. Commodi aut a et quam voluptas omnis molestiae. Sed amet nisi aut.</p><p>Officiis dolorem fuga voluptatem quo. Unde et placeat in at qui voluptatem. Perferendis maiores ut ipsa ut. Ipsum cum eius qui ea quo nisi.</p><p>Quod omnis minima a dolorem. Ipsum sint occaecati similique aut sit molestias ut esse.</p>',0,5,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(9,'So they began running when they liked, and left.','<p>Adipisci molestiae et consequatur perferendis nemo numquam quaerat. Autem qui cupiditate autem optio dolor ratione. Consequatur odio recusandae doloremque earum officiis exercitationem totam. Tenetur deleniti laboriosam quia. Ut libero veritatis vel aliquam sed et optio est.</p><p>Qui ratione et cum aut sint nesciunt ipsum. Quis nam distinctio ut voluptate. Temporibus aliquam sequi et ullam ipsam. Labore omnis ex et possimus.</p><p>Accusantium aut doloribus consequatur non. Tempora iusto sunt vel aut delectus. Autem placeat aliquam molestiae ullam. Enim modi consequatur rerum nam tempore fugiat.</p><p>Ratione et et iure non soluta voluptas in. Est modi hic libero aut libero. Omnis hic in et cupiditate ipsum exercitationem. Quo ad aspernatur totam non.</p><p>Eligendi non perspiciatis similique quas reiciendis quia reiciendis. Sit sint nisi sunt autem doloremque commodi consequuntur. Quis et officiis quia est reprehenderit omnis libero.</p><p>Ea quae omnis quisquam fuga nesciunt autem et. Culpa laboriosam suscipit porro tenetur. Et nihil sit et praesentium.</p><p>Quo ratione numquam alias labore fugiat quod. Et velit ratione quas voluptatibus ea dolores. Excepturi quis incidunt eaque distinctio sed voluptatem ipsam. Quo blanditiis blanditiis rerum nihil ut fugiat.</p><p>Omnis iure doloremque tempora autem consequatur beatae delectus. Quaerat hic in vel doloribus voluptate nemo. Voluptas inventore molestiae harum aut. In sapiente nesciunt fugit tenetur vel id sed.</p>',0,2,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(10,'Laughing and Grief, they used to queer things.','<p>Magni ratione qui amet sint eaque est vel. Et iste dolorem voluptatum voluptatibus blanditiis iste et. Dicta odit sed et nemo id aliquid velit necessitatibus. Et mollitia sunt qui earum aut perspiciatis. Tenetur vitae maiores doloribus quo rerum aspernatur.</p><p>Sunt quo iure sit et. Mollitia natus neque ut qui qui numquam omnis. Incidunt temporibus eos eveniet itaque molestias. Nostrum rerum inventore adipisci.</p>',0,3,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(11,'I then? Tell me that first, and then, if I was.','<p>Quia nihil quidem dolor similique voluptatem. Voluptatem sapiente est aut sint non et voluptatem.</p><p>Eos provident aut qui quo quia. At corporis distinctio est. Tempora dolorem sunt quidem. Enim enim et rerum in blanditiis quae.</p><p>Vero ab repellat perferendis et et nesciunt. Molestiae dolorem est recusandae. Minima voluptatem optio totam qui earum voluptatem.</p><p>Consequatur officiis et neque dicta molestiae est eos. Vel est at quia quo. Aperiam corporis doloremque ratione.</p><p>Voluptatem in odit in qui dolores. Et et est iusto iure. Dolorem in voluptas velit expedita temporibus expedita. Nam magnam quia temporibus est tempore error deleniti.</p>',0,7,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(12,'Alice\'s, and they went on just as usual. I.','<p>Accusamus ex ipsa autem aperiam explicabo. Non neque soluta laborum consequatur est. A autem ducimus molestiae aut vitae laborum. A eius nobis incidunt consequatur dolor libero repudiandae. Animi sunt facilis consequatur fuga voluptatum.</p><p>Eius rerum aut iusto enim voluptatem ipsam sit velit. Impedit architecto eum tempore eaque soluta deserunt. Ducimus expedita et itaque. Magnam unde voluptas ratione et.</p><p>Tempore optio nam voluptate quisquam quasi et vitae molestias. Voluptate id atque architecto doloremque aut pariatur. Sapiente non est cum. Est et necessitatibus repudiandae doloremque beatae.</p><p>Quo non blanditiis earum voluptates. Velit maiores voluptatem quis aut eius. Ipsum ipsa dignissimos maxime. Doloribus aliquam modi impedit dignissimos laboriosam corrupti reiciendis. Voluptatem sed id quisquam.</p><p>Est odit aut sed ea neque vel. Laudantium sit autem ut illum ratione et quis. Sunt aut dicta fugit est. Officia aliquid non iste sit nihil rerum.</p><p>Sed culpa et ipsa molestiae a hic iure. Eum libero iusto quas veritatis possimus eligendi vel. Voluptates vel adipisci id in. Omnis id dolores corporis commodi.</p><p>Aut doloremque consequatur recusandae non quam aut. Aut commodi voluptas excepturi ut perferendis dolores id. Natus sed explicabo aut. Culpa tenetur eos et aut.</p>',0,1,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(13,'Game, or any other dish? Who would not stoop?.','<p>Asperiores esse ea et non. Pariatur dolorem facere sit dolorum soluta blanditiis. Et sapiente et sunt rerum. Sit accusantium temporibus rem fugiat aliquam. Cupiditate quia illum ea id.</p><p>Quidem eos suscipit libero. Doloremque repellendus delectus dolore quidem vitae molestiae enim fugiat. Sed voluptas accusantium expedita quam.</p>',1,5,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(14,'And then, turning to Alice. \'Only a thimble,\'.','<p>Voluptas architecto distinctio et recusandae. Animi ipsum eligendi quia eum aliquam. Est neque sunt omnis temporibus accusantium. Quo in et qui.</p><p>Neque qui et eaque aliquid temporibus. Voluptatem dolorum ex non rerum. Quaerat iste recusandae numquam fugiat ratione. Doloribus ut quas assumenda error.</p><p>Distinctio velit quaerat facere assumenda quia. Ab quis odio at voluptatem sint voluptatum. Omnis placeat corporis sunt natus facere consequatur. Delectus veritatis eligendi unde porro accusamus dolores quasi.</p><p>Quam repudiandae quas aut ratione. Aliquid earum officiis minus iure. Sit qui eaque blanditiis molestias et dolor quisquam deleniti. Dignissimos voluptas itaque facilis in autem quos magni. Consectetur porro mollitia nostrum iste aliquid corporis.</p><p>Vel quam provident ullam explicabo est. Modi beatae vitae sed nihil veritatis. Aut corrupti porro officia. Laudantium quos quod et quod.</p><p>Ea exercitationem velit tenetur. Voluptatem nesciunt dolorum velit ipsum. At vitae excepturi adipisci quos aut maxime qui.</p><p>Quae rerum esse ut quia mollitia iusto omnis et. Omnis voluptatibus corrupti sed vel sit delectus. Amet est atque nulla nulla at.</p><p>Eum at quos in quod. Sunt sit qui eius quis quas sunt. Quo mollitia iste tempore accusantium. Consequuntur et voluptatibus quis facilis libero.</p>',0,5,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(15,'Gryphon, the squeaking of the e--e--evening.','<p>Eius quas voluptas repudiandae exercitationem quidem. Facilis consequatur aperiam illum voluptatum quod praesentium exercitationem. Adipisci consequuntur voluptate id ab est. Quas neque facere enim veritatis dolor ducimus animi.</p><p>At occaecati quos ullam beatae. Commodi eos dolor fugit consequatur possimus aliquam sint. Et dicta cum aperiam assumenda id aut. Architecto dolorem tempore rem error totam enim cum.</p><p>Rerum aut aut molestias ipsum incidunt quibusdam. Sunt aperiam autem perspiciatis ullam. Deleniti deleniti perspiciatis incidunt quidem exercitationem nulla reprehenderit quis.</p><p>Officia eos aliquam totam culpa ut rerum velit sit. Perferendis eos accusamus consectetur nihil eos laudantium adipisci. Aut hic nobis ullam inventore officiis sit illum inventore.</p><p>Et delectus aut a maxime et voluptate reprehenderit. Enim iusto minima in cumque qui. Dignissimos et fugiat aut aspernatur. Et suscipit est enim quidem sed delectus.</p><p>Sed sit consequatur quae voluptatem. Voluptas eos officia ad animi dolorem pariatur asperiores. Est ab et eligendi quod mollitia fugit. Exercitationem aut debitis repudiandae.</p><p>Sit mollitia molestias et. Voluptatibus dolorum nostrum repudiandae magni ab. Ullam quas eum voluptatem consequatur ut qui tempora. Praesentium id ut eum vitae et rerum est.</p><p>Repellendus quae amet non quia vitae. Molestiae repudiandae aut distinctio.</p>',1,2,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(16,'It did so indeed, and much sooner than she had.','<p>Expedita consequuntur quo est harum. Tempora molestiae assumenda ea qui. Beatae hic saepe saepe unde quo distinctio nesciunt. Rerum qui ullam aut hic. Accusamus soluta qui veniam error.</p><p>Quam fuga illum non consequatur ut aut blanditiis. Sed nihil quam error pariatur natus dolores. Id eos dolor non deserunt necessitatibus. Eaque et eum voluptatem ut qui ipsam.</p><p>Sit quam dolor reiciendis consectetur debitis. Ut harum omnis ipsam porro sit consequatur. Harum animi magni est ad aut eligendi.</p>',0,6,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(17,'IN the well,\' Alice said nothing; she had not.','<p>Fugit sunt libero suscipit omnis. Amet distinctio vero voluptate repellat. Error quia aut qui sed.</p><p>Reiciendis eaque sit sed quisquam. Asperiores aut consectetur soluta natus hic officia qui doloribus. Et quia sunt at. Qui aut excepturi placeat cumque tempore provident animi quidem.</p><p>Eum ut in amet qui dolore qui. Aut ipsa aut cupiditate eos ut est provident. Consequuntur harum quia ut maxime placeat ut distinctio molestias. Et magni sed quia hic consequuntur suscipit quia.</p>',1,3,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(18,'I\'m not particular as to size,\' Alice hastily.','<p>Optio vel ipsum odio sapiente et. Soluta ab sunt quia sint et ut voluptas. Molestiae alias aliquam ducimus dolor nostrum fuga et.</p><p>Et velit officia esse. Quas dolor est velit error minus voluptatem. Magni illo nulla ex est ipsam. Quam vel aut tenetur porro iure.</p>',0,1,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(19,'By the time he was in the direction it pointed.','<p>Aut omnis est nulla perferendis doloribus. Et expedita dolor aut earum. Sit id harum aliquam.</p><p>Velit ea repellendus nulla. Libero quidem rerum et ad. Ipsa ut est sed. Nesciunt commodi qui consequuntur doloribus omnis vitae.</p><p>Enim et et dolorem nihil corporis. Totam reprehenderit accusantium molestias magnam expedita eos. Quibusdam facere qui et dolor.</p><p>Consequuntur eius odio sed. Enim ipsa et quia accusantium voluptatem omnis nemo. Repellat quis voluptates illo rerum. Ab ut vel tempora culpa est vitae labore reprehenderit.</p><p>Dolorem commodi porro ut aut ipsam omnis. Pariatur non repellat ut est. Dignissimos adipisci rerum est minima rem molestias quos sunt. Adipisci quam voluptatem laborum eius perspiciatis inventore vero.</p><p>Repellat laborum harum dolore consequatur excepturi magni. Aut ea adipisci quae et. Et ut sit eos. Accusamus omnis assumenda qui est perferendis.</p><p>Cum quia temporibus distinctio labore maxime. Sed sed repellendus aut aspernatur. Debitis et quo itaque.</p><p>Sunt rerum illum consequatur quaerat libero quia repellat. Sit consequatur odio et omnis. Reprehenderit necessitatibus molestiae sint quibusdam voluptatem minima.</p>',1,1,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(20,'Morcar, the earls of Mercia and Northumbria--\"\'.','<p>Eius voluptas similique tempore id. Consequatur quis ut et blanditiis quisquam. Corporis enim esse quis assumenda. Dignissimos et illo vel corrupti ipsam recusandae.</p><p>Autem est inventore amet. Reiciendis veniam quia aut incidunt. Quae eos quas voluptatem et ipsam blanditiis dolor id. Nobis esse placeat quod.</p><p>Vel nostrum provident dicta dignissimos eos dolores a. Velit eligendi dolores neque. In laboriosam rem dolorum deleniti et. Vero illo qui nulla consequuntur sunt.</p><p>Reprehenderit voluptas id autem aut. Molestiae quae necessitatibus eum vitae quas ea. Sed sed laboriosam ut enim. Ut aut possimus aut.</p><p>Commodi at ipsum aspernatur animi omnis sit reprehenderit. Et asperiores ab sed amet eius. Quas ut necessitatibus accusamus qui beatae. Occaecati sit numquam similique ut.</p><p>Qui omnis harum enim et magnam molestias illo. Sint consequatur possimus placeat repudiandae tempore maxime. Temporibus debitis minima voluptas est. Facilis accusamus veritatis exercitationem saepe voluptas amet.</p><p>Laudantium vel voluptatibus placeat quos. Ut ut ullam eum ipsum minima. Cum et eum fugiat.</p><p>Doloribus aut ullam et inventore placeat voluptas dolores. Ratione consequatur eligendi veniam possimus assumenda. Vel dolores beatae asperiores eveniet autem.</p>',0,1,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(21,'The Rabbit started violently, dropped the white.','<p>Fugiat sint ipsum qui et laboriosam. Similique explicabo ducimus consequatur quo. Vel et nihil quibusdam qui officiis nobis. Aut neque sit inventore ut quisquam. Assumenda assumenda eos deleniti eos quae amet sunt.</p><p>Quasi nihil soluta aut molestiae animi debitis. Voluptates molestias quaerat molestiae distinctio totam modi alias. Enim consequatur earum nam nam omnis ut et consequuntur.</p><p>Deleniti dolor doloremque exercitationem excepturi commodi deleniti. Nam hic ipsam nam temporibus alias rerum reiciendis eaque. Et incidunt aut nisi adipisci.</p><p>Blanditiis dignissimos et suscipit fugit sed qui modi. Atque inventore reprehenderit est repellat in qui autem. Aut natus quia quisquam corporis dolore et labore.</p><p>Debitis quo corrupti perferendis ut qui. Et suscipit rem cupiditate mollitia modi. Unde est sequi rem qui magni cum.</p><p>Et adipisci vitae eligendi sint. Quia sit maiores vel perspiciatis. Ut autem non dicta facere.</p><p>Maiores est exercitationem neque aliquam quis. Voluptates qui eligendi et natus et. Ullam et aut molestiae amet aut aut libero. Dolores aperiam voluptatem corrupti explicabo omnis dolor et numquam. Velit consequatur pariatur beatae officiis impedit consequatur.</p>',1,1,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(22,'Cheshire Cat: now I shall be late!\' (when she.','<p>Quidem nihil adipisci quaerat voluptate blanditiis facilis velit. Quas corrupti soluta beatae natus aut inventore laboriosam dolor. Quo autem recusandae et magnam maxime quaerat est. Quia nemo atque non qui et quis.</p><p>Esse id dolor molestiae delectus vitae. Saepe vitae voluptas et molestiae. Maxime quia ut adipisci nemo.</p><p>Nihil enim voluptas numquam id voluptatem. Nisi at ullam id sint aliquam ea voluptas tempore. Fugit enim soluta et ex rerum eius. Odit nesciunt molestias exercitationem veritatis et dignissimos. Esse explicabo ad eum eum voluptas voluptas at.</p>',0,2,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(23,'I\'m here! Digging for apples, yer honour!\' (He.','<p>Doloremque dolorum facere ab quidem repellendus iste nulla. Sit repellat velit voluptate fuga. Aut fugiat dolores non.</p><p>Omnis reiciendis cumque dolorum amet eum. Aspernatur ipsam eius non fuga expedita aspernatur. Beatae minus tempore fuga assumenda quas quae rerum. Rerum excepturi similique iure beatae nemo.</p><p>Dolorem facilis velit deserunt hic culpa. Dolores omnis quis natus est voluptatem. Rerum accusantium occaecati qui ut.</p>',1,7,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(24,'Alice replied very readily: \'but that\'s because.','<p>Unde quae beatae nam voluptatem mollitia vel officia. Iure quia laudantium tempore illum quo. Iusto tempore modi mollitia repudiandae eos sunt at ipsa.</p><p>Aliquam magni repellat officia ut veritatis omnis. Quia consequatur sint illo aut ipsam qui dicta cumque. Labore est libero ducimus incidunt. Vel quas ratione in aut magni.</p><p>Sit ut rerum earum sit. Enim dicta voluptas qui fuga sed similique dolores.</p><p>Ut error quos ratione ut fugit odio. Molestiae corporis non dolor est sed corporis tempora.</p><p>Vitae voluptatem accusantium et omnis cupiditate dolorem voluptas. Quisquam quod vel fugiat saepe porro sed qui. Possimus ut non rerum cupiditate et perspiciatis consequuntur. Facilis sequi saepe sed ducimus quis aut libero.</p><p>Ipsa perspiciatis ea voluptate id corrupti. Quibusdam dolorem sequi eos est quae. Repellendus pariatur recusandae ea sunt.</p><p>Libero exercitationem amet nostrum vel deleniti. Et iste sapiente et. Doloremque ut sint earum qui quia facilis est nisi. Optio eligendi distinctio repudiandae ratione. Quia at rerum consequatur error reiciendis nisi vel.</p><p>Dolores neque et sed eligendi qui fugit voluptatem. Aperiam dolorum ducimus sapiente molestias. Eum sapiente quis omnis sint magni.</p>',0,6,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(25,'There was exactly the right words,\' said poor.','<p>Blanditiis in doloremque dolorum occaecati voluptas omnis vel. Ad quo at doloremque consequatur. Nesciunt quia doloremque sit labore blanditiis ab dolores.</p><p>Minus expedita fuga sed ut ipsam aut. Facere maiores quo vel quisquam at at quod modi. Possimus distinctio vero alias eligendi hic aut nobis. Omnis quo aut enim alias temporibus velit hic sit.</p><p>Voluptatem veniam qui aut. Tempora eos itaque adipisci at ratione. Eius recusandae praesentium sit autem nihil iste nobis modi.</p><p>Inventore sit quis accusantium exercitationem dolor omnis dolorem architecto. Reprehenderit voluptatibus saepe iste placeat possimus qui quos. Dolor temporibus veniam consequatur cumque. Consequuntur quo iure et. Consequatur enim qui cum.</p>',1,6,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(26,'Indeed, she had someone to listen to her, And.','<p>Est ad similique labore odio sit sunt expedita deserunt. Est ut in omnis. Ut aspernatur dolorum qui facilis velit sed unde aut.</p><p>Dolorum soluta veniam quas expedita. Ipsa ut enim officiis unde possimus sit. Magni dolor cumque ratione expedita ratione consectetur itaque.</p><p>Suscipit molestiae dolor voluptatem in ut accusamus occaecati. Voluptas eos impedit et sequi animi vitae blanditiis. Ut natus consequuntur aut qui.</p><p>Pariatur ut eaque eius enim dolorem dolor et voluptates. Minus incidunt repellendus rerum perspiciatis asperiores. Non libero et temporibus veniam qui. Voluptas culpa earum soluta neque velit.</p><p>Ut sint consequatur ab et. Numquam veritatis sunt atque iusto. Laudantium fuga voluptatum eveniet ratione quia et et autem.</p><p>Voluptate atque illum voluptatibus ab minima sint iure. Quibusdam nemo veritatis sunt magni nesciunt ratione debitis quia. Sint doloremque vel dolores sed occaecati quia.</p><p>Dolore maiores aliquam qui in et quia. Expedita eum voluptatem accusamus ut dolores. Est maxime quidem beatae doloremque vel a veritatis hic. Pariatur ab corrupti earum qui labore nostrum.</p>',0,5,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(27,'Queen. \'Can you play croquet with the clock. For.','<p>Rerum sunt quod et nobis. Assumenda sed quia modi est qui. Quibusdam nesciunt et eaque debitis necessitatibus. Autem quod ut repellendus rerum. Perferendis vero unde neque ullam.</p><p>Quo harum aut nam vitae amet. Consectetur vel quaerat rerum inventore possimus provident dolorem esse. Voluptatem consequuntur aut eos magnam.</p><p>Sequi officia sint eaque quasi. Nemo sapiente beatae soluta et enim omnis quia labore.</p>',0,2,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(28,'The other guests had taken advantage of the.','<p>Aut non explicabo autem vel consequatur qui aliquam. Omnis eos maiores doloremque vel fugit nostrum. Suscipit in fuga non aut labore minus reprehenderit. Eveniet eos iure neque sint rem. Aliquid error excepturi dolorum ratione nihil harum aut.</p><p>Sit perspiciatis sit consequatur perferendis ratione fugit non recusandae. Sed fugiat eum dolorum suscipit dicta. Exercitationem at omnis nemo et atque odit ex. Et dicta et praesentium dolorum qui quia.</p><p>Omnis earum sit doloremque. Dolorem voluptas vero sit facere pariatur porro. Neque rem quae ut quas. Et atque autem doloribus et sint repudiandae.</p><p>Maiores similique architecto excepturi aliquid error provident. Id unde quis nemo dolores dolores consequatur qui. Sit quam deleniti saepe.</p><p>Illo fuga placeat ex deserunt beatae totam. Ipsa eveniet quia ipsam laudantium asperiores magnam. Voluptate modi veritatis quia.</p>',1,2,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(29,'Mock Turtle said with some difficulty, as it.','<p>Sit sequi laboriosam doloribus quam numquam saepe non. Magni quos eos omnis voluptatem nihil quisquam. Officia doloribus nulla velit sit.</p><p>Et nihil dolores quia ipsum quis voluptatum molestiae et. Consequatur pariatur aut adipisci architecto vel. Temporibus commodi in corrupti sunt. Autem voluptas in eligendi doloribus similique.</p><p>Aut debitis ipsa rem sequi sed. In sed nisi inventore rerum. Rerum et est sunt quaerat.</p><p>Veritatis sed quas qui. Id aut nisi et voluptatibus nobis rerum enim adipisci. Laborum quis voluptas enim odit. Dolor est facilis beatae omnis perferendis.</p><p>Dolores voluptatem maiores et ratione vitae consequuntur quo. Tenetur quia id nisi nostrum a autem. Quasi voluptatem saepe ducimus labore.</p><p>Libero rerum mollitia eius dolorem at nulla dolorum. Accusantium adipisci atque aut dolores consequuntur. Rerum corrupti aut animi ea. Dolorem perspiciatis aut consequuntur nulla quas. Qui soluta iusto non at unde facere eveniet.</p><p>Aut non recusandae voluptatibus sunt. Aliquam magnam dolores voluptatem omnis. Est a quas consequatur maxime commodi nostrum. Tempore necessitatibus quibusdam et blanditiis placeat.</p><p>Debitis dignissimos omnis repellat cum neque iure. Sunt numquam aut ad eum dolorum adipisci qui. Nisi maxime et numquam repellendus.</p>',0,4,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(30,'Eaglet. \'I don\'t see any wine,\' she remarked.','<p>Repellat labore voluptate qui voluptatem. Sit atque consequatur assumenda aut assumenda est. Veniam id aut sit enim quas adipisci dolorum. Aut id est deleniti provident ut.</p><p>Aperiam sequi molestiae ducimus tempora. Earum qui in assumenda repellat. Vel sapiente temporibus et dolorum. Impedit qui error quo.</p><p>Et porro aut fugit amet. Quae aliquam autem tempore id eos.</p><p>Eos enim expedita nisi voluptatem quam ipsam iusto explicabo. Fugiat ea voluptate et ut. Voluptatem aut voluptate distinctio modi corrupti a dicta. Et voluptas et velit quia iste saepe voluptatem quam.</p><p>Hic libero eligendi error assumenda et. Error voluptas eum voluptatem non tenetur. Similique eum aperiam nihil quo. Consequatur optio similique distinctio minima quae.</p><p>Sed vitae velit velit velit voluptate assumenda. Eius nulla aut amet ut itaque accusantium culpa tempora. Quia veniam fugit inventore voluptatum. Iusto tempora consectetur eum aliquam ut.</p>',0,3,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(31,'The Hatter opened his eyes. He looked at the.','<p>Suscipit hic sint dolores distinctio quia. Eveniet voluptas corporis voluptas labore nobis et. Neque corrupti aut sit blanditiis deserunt quam.</p><p>Pariatur molestiae reiciendis rem expedita perferendis illum omnis. Sunt magni at odio debitis. Veniam quia ipsam beatae. Non iste qui dolores aut.</p><p>Incidunt est ea qui aut. Inventore veniam facilis non et. Est dolor laborum consequatur rem qui qui.</p><p>Fugit id qui accusamus amet optio sed dolorum. Officia aut velit aut dicta. Rerum blanditiis ea quia accusantium. Sed ea nostrum omnis.</p><p>Laborum voluptas sunt praesentium dolores. Sint beatae et ipsa voluptatem accusamus cum. Hic non nesciunt aut. Ipsum deserunt minima necessitatibus impedit eius laudantium explicabo. Ut nisi dolor et dolores.</p><p>Voluptatem vitae rerum a deserunt voluptatum. Sit culpa eos dolorum rerum. Vel incidunt iure debitis qui dolor fugit. Facilis cum quasi quas est saepe sint.</p>',1,2,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(32,'However, he consented to go down the hall. After.','<p>Fuga veritatis quam sit tenetur. Quas modi rerum suscipit ea quia ullam. Vero voluptatem facilis consequuntur laboriosam. Repellendus culpa sint minima ipsum id qui.</p><p>Et reiciendis dolorem quia aliquid. Molestiae totam quo rerum. Consequatur id at omnis natus voluptates iste veniam ipsum. Debitis quo dicta ut sed nisi vel.</p><p>Sit et commodi atque rerum maxime id maiores. Tenetur dignissimos non in repudiandae nihil. Expedita quas omnis fuga sint ut. Atque eum aut eius et quos.</p><p>Magni sunt explicabo itaque quam. Unde eius itaque quaerat dolor quam aliquid tempora. Quis incidunt neque rem est architecto. Amet dignissimos iste quas perspiciatis.</p>',1,7,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(33,'Alice asked in a minute. Alice began to repeat.','<p>Quisquam nihil facere optio deserunt quis sed laboriosam. Et ut cum et aut vero ratione. Consectetur est placeat est quod sint. Ipsum beatae aut quis illo ratione nemo aut.</p><p>Nulla est repudiandae cum. In maxime modi nulla voluptas. Atque nihil inventore minima ut. Sunt labore labore iste sint nihil provident.</p><p>Nisi nesciunt vero rerum consequuntur aut iste quis. Hic voluptate ratione sunt nesciunt magni harum quia. Quia ut et eveniet beatae corrupti beatae eum quae.</p><p>Praesentium minima praesentium sint ratione voluptatum est consequatur. Voluptates qui veniam doloribus placeat qui. Omnis mollitia officiis eveniet. Accusamus quaerat quasi vitae nam.</p><p>Sequi repudiandae placeat molestiae consequatur ipsa. Commodi iusto vitae non eius voluptatem.</p><p>Repellat delectus a recusandae minima. Qui explicabo omnis architecto non fuga sapiente eveniet quibusdam. Aliquid assumenda explicabo minima consequuntur harum quo nihil.</p><p>Maiores corporis sit quae repudiandae quia voluptatibus sit. Eum modi expedita eligendi corrupti. Molestiae unde nulla assumenda vero dolorem et vitae. Inventore ut et ipsa et ut.</p><p>Alias soluta consectetur eum. Sed qui ex dolor reiciendis ipsam atque. Inventore vitae dolorum vitae enim.</p>',1,6,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(34,'But the insolence of his tail. \'As if I chose,\'.','<p>Sequi exercitationem est iste dignissimos. Animi praesentium deleniti culpa fugit quidem nihil temporibus quia. Aperiam ullam labore molestiae quia beatae molestias.</p><p>Eligendi ea iste sed at voluptatem quaerat expedita. Velit voluptates quae incidunt fuga ut est consequatur. Facilis cumque voluptates est et error sed atque.</p><p>Alias perspiciatis illum facere eos qui et similique. Fugit voluptatem blanditiis esse quidem voluptate similique. Assumenda iste non voluptatem qui.</p><p>Quia ut totam tempore alias. Deserunt et est voluptas exercitationem. Tenetur molestiae vel eius soluta rerum repellendus.</p><p>Earum ut facere qui voluptatem. Eligendi enim ipsum est dolores quos officia. Eius eos quasi alias dolores perferendis. Ea earum modi voluptatem aut accusantium mollitia consequuntur.</p><p>Sed ipsum reiciendis repellat aperiam earum optio. Repudiandae sit officiis sed quidem perspiciatis. Qui vel quia autem.</p><p>Facere repellendus sapiente voluptatem non eligendi suscipit. In mollitia quos aut id. Dolor eum nam accusamus dicta exercitationem. Et cupiditate officia voluptatem autem nisi consequuntur reprehenderit.</p><p>Minus error et et delectus. Natus non assumenda consectetur non animi quisquam ullam. Beatae et occaecati dolorum minus nihil quis est asperiores. Rem ut quasi eos nesciunt similique provident.</p>',1,5,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(35,'It was, no doubt: only Alice did not venture to.','<p>Architecto totam reprehenderit aut ut cumque ea ratione adipisci. Corporis placeat quidem distinctio et quia voluptatibus. Libero non ullam qui saepe eveniet culpa velit.</p><p>Est et rerum id nulla nulla. Dicta iusto non fugit error et. Qui quia minima fugit rerum molestiae ab.</p><p>At harum quam et earum. Praesentium illo nihil voluptatem sit autem quos porro.</p><p>Et pariatur qui est quam ut quasi voluptate. Maxime dolor voluptas nam a aut. Velit itaque illum iure vitae quibusdam quaerat quaerat ut.</p>',1,4,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(36,'I\'ll just see what was the White Rabbit read.','<p>Impedit rerum eligendi eaque architecto voluptatem. Necessitatibus consequatur deleniti vel et.</p><p>Voluptas facilis est ullam perspiciatis fugiat enim ut. Rem quibusdam odit ullam. Optio dicta voluptate enim ipsam ex facilis minus vel.</p><p>Deleniti eum alias ut. Ut ratione nihil aspernatur eos. Blanditiis qui natus et eligendi illo iste iure. Quisquam excepturi architecto enim inventore nemo quo vel.</p><p>In eos assumenda blanditiis quis aspernatur. Ea doloribus odit quidem et fugiat. Consequuntur quasi expedita sed perspiciatis nihil ut est aut.</p><p>Quam sequi nam et illo quisquam tempore earum odio. Ea aliquam qui aliquam. Est debitis amet eveniet voluptatibus odit. Cumque natus illum vitae alias voluptatem repellat delectus.</p><p>Eaque voluptatem et voluptas porro voluptas corporis. Debitis minima dolore suscipit ea cum quisquam beatae. Rerum est dolor mollitia sed ut et sequi. Voluptas adipisci adipisci a consequatur non.</p><p>Quod sunt illum esse possimus voluptates cumque debitis. Vel nesciunt ut saepe consequatur aliquam qui. Rerum optio suscipit eum dolorem est veritatis id. Est odit impedit esse voluptatum vel unde laborum delectus.</p>',0,1,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(37,'Duck and a crash of broken glass, from which she.','<p>Quis nemo et atque voluptatibus laudantium. Nam nesciunt fugiat aliquid excepturi eveniet et.</p><p>Quae qui ratione dolorem consequatur et. Eligendi inventore amet inventore. Facilis nihil iusto laboriosam et.</p><p>Nihil consequatur quaerat quibusdam pariatur. Ut et eos magnam consectetur non. Sint rerum ducimus similique ab soluta nostrum.</p><p>Voluptas occaecati sapiente quibusdam eius dolorem. Deleniti odio dolor non accusantium. Qui sed tempora error vel. Nemo voluptatum nemo cum debitis minus.</p>',0,4,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(38,'What happened to me! I\'LL soon make you grow.','<p>Reiciendis error cumque non atque sit. Corrupti dolores est molestiae deserunt laboriosam. Suscipit libero doloremque perferendis sequi aut itaque.</p><p>Vel voluptas sit perspiciatis. Nemo voluptatem aut ratione similique et perspiciatis dolor assumenda. Explicabo praesentium quae expedita odit est sed.</p><p>Enim et doloremque culpa atque quas perspiciatis qui. Aut modi officiis in rem velit quasi quo. Sapiente adipisci et perspiciatis qui.</p><p>Adipisci itaque dolorem beatae voluptatibus id sint temporibus. Maiores ut ab id libero.</p><p>Tempore omnis rerum culpa at quis cum. Et aut et libero ullam quasi. Perferendis necessitatibus rerum voluptatem et. Possimus atque tenetur nobis unde aut et.</p><p>Atque doloremque eligendi sint tempore in. Autem quisquam nobis maxime sit reiciendis quae. Laborum quo provident quia deleniti est id. Suscipit non repudiandae totam repellendus laborum eligendi corrupti aut.</p>',1,7,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(39,'Duchess\'s knee, while plates and dishes crashed.','<p>Voluptatem dolores eum laboriosam. Velit molestiae et cum hic qui blanditiis dolor. Ut omnis veniam voluptas dolorem non saepe omnis quo. Non laborum nihil quia et dolores et.</p><p>Enim velit itaque sed ut est. Voluptatem est numquam iste molestiae nihil dicta totam. Laboriosam explicabo fugiat sed et hic qui.</p><p>Officiis quos est at in voluptatem quod. Rerum dolorem vel similique dolorem quo explicabo omnis. Mollitia et dolores et et. Harum eius dolor sunt qui enim repellat.</p>',1,4,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51'),
	(40,'Why, there\'s hardly room to open it; but, as the.','<p>Odio non explicabo vitae et iusto. Sed incidunt at ut sit id minima iusto. Laboriosam aliquam consequatur ipsa officia perspiciatis.</p><p>Impedit eum facilis ab consequatur. Tenetur animi commodi ut doloremque maxime impedit veritatis. Repellendus laboriosam repudiandae odit ea adipisci ipsam possimus.</p><p>Sint molestiae quas est eligendi. Distinctio veniam qui ut temporibus dignissimos sunt. Consequatur sapiente minus voluptatibus ipsa.</p><p>Laboriosam nemo ex eum rerum eligendi asperiores voluptate voluptatibus. Veniam consectetur dolores voluptas velit. Culpa sunt vero ipsa explicabo temporibus at velit velit. Velit ipsam quia nam eligendi ducimus sint.</p><p>Voluptate vel numquam iste beatae dolorem et dolorum. Iure doloribus consequuntur animi repellat et et culpa. Assumenda sit sed est explicabo ad eum libero.</p><p>Vero sed repellendus voluptatum enim dolorum. Facere facilis ut aut est repellendus dolor exercitationem. Magnam magnam dolor molestias. Adipisci qui qui placeat quis facilis sit inventore corporis.</p>',0,7,'2022-11-29 16:59:51','2022-11-29 16:59:51','2022-11-29 16:59:51');

/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`)
VALUES
	(1,'Simon Ainley','simon@87development.co.uk',NULL,'$2y$10$kAxIRUTQBVB2MtpxusULUuKJmXmNSaEAy5Bv3eSamBGVYYqa1STny',NULL,'2022-11-29 17:09:27','2022-11-29 17:09:27');

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
